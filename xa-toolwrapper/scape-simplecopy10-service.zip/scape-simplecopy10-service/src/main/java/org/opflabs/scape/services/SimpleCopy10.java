package org.opflabs.scape.services;

import org.opflabs.scape.services.proc.CommandLineProcess;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.om.OMNamespace;
import org.apache.axis2.context.MessageContext;
import org.apache.axis2.description.Parameter;
import org.opflabs.scape.services.util.FileUtils;
import org.opflabs.scape.services.util.StringUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Simple copy version 10 service class.
 */
public class SimpleCopy10 {


    /**
     * Static logger variable.
     */
    private static Logger logger = LoggerFactory.getLogger(SimpleCopy10.class.getName());

    /*
     * These variables can be mapped to an output port using the OutputMapping
     * property in the output configuration file (data types must be the same).
     *
     */
    private boolean processing_success;
    private int processing_returncode;
    private String processing_message;
    private String processing_log;
    private int processing_time;
    private String processing_unitid;

    {
        processing_success = false;
        processing_returncode = -1;
        processing_message = "";
        processing_log = "";
        processing_time = 0;
        processing_unitid = "http://null";
    }

    /**
     * Apply process to the input object.
     * @param inImgFile Input image file.
     * @throws IOException
     */
    private boolean process(HashMap<String, String> cliCmdKeyValPairs, int opid) {

        // Assigning values to the variables used in the command pattern.
        // If additional variables are required, they must be added in the
        // org.opflabs.scape.tb.service.CommandPatternVariables class.
        String cliCmdPattern = getValueOfServiceParameter("cliCommand" + opid);

        // Command line process
        CommandLineProcess clp =
                new CommandLineProcess(cliCmdPattern, cliCmdKeyValPairs, false);
        try {
            clp.init();
        } catch (IOException ex) {
            processing_message = "I/O Exception. " + ex.getMessage();
            processing_success = false;
            return false;
        }
        clp.execute();
        processing_success = (clp.getCode() == 0);
        processing_returncode = clp.getCode();
        processing_log += clp.getProcessingLog();

        // The return codes of the tool should be documented here by
        // creating a case for each code and assigning the corresponding
        // message.
        switch (processing_returncode) {
            case 0:
                processing_message = "Process finished successfully with code 0";
                infolog(processing_message);
                break;
            case -1:
                processing_message = "Process result is undefined with code -1";
                errorlog(processing_message);
                break;
            default:
                processing_message = "Process failed with error code " + processing_returncode + ". ";
                errorlog(processing_message);
                break;
        }

        return processing_success;
    }

    /**
     * Service operation
     * @param inputUrl Input url
     * @return Response message subtree
     */
    public OMElement simpleCopy(String inputUrl) {

        infolog("========= PROCESSING REQUEST =========");
        infolog("Using service: SCAPESimpleCopy10Service");

        String processingUnit = this.getValueOfServiceParameter("processingUnit");
        if (processingUnit != null && !processingUnit.isEmpty()) {
            processing_unitid = processingUnit;
        }

        OMFactory fac = OMAbstractFactory.getOMFactory();
        OMNamespace omNs = fac.createOMNamespace(
                "http://opflabs.org/scape/services", "tns");

        // Required for copying output files
        String publicHttpAccessDir = getValueOfServiceParameter("publicHttpAccessDir");

        // Required for providing access to output files
        String publicHttpAccessUrl = getValueOfServiceParameter("publicHttpAccessUrl");

        // Command pattern variables key value pairs
        HashMap cliCmdKeyValPairs = new HashMap<String, String>();

        //<!-- input_code -->//
        String outputFileName = FileUtils.getTmpFile("SCAPESimpleCopy10Service_outputFile_", "png").getAbsolutePath();
        cliCmdKeyValPairs.put("OUTFILE", outputFileName);

        // inputUrl
        URL url = null;
        try {
            url = new URL(inputUrl);
            infolog("URL of input file: " + url.toString());
        } catch (MalformedURLException ex) {
            errorlog("\"" + inputUrl + "\" is not a valid value for the "
                    + "parameter \"inputUrl\"");
            return getResult(fac, omNs);
        }
        String inputExt = StringUtils.getFileExtension(inputUrl.toString());
        if (inputExt == null) {
            inputExt = "tmp";
        }
        File inputFile = FileUtils.urlToFile(url, inputExt);
        if (!inputFile.exists()) {
            errorlog("Input file " + url.toString() + " is not available");
            return getResult(fac, omNs);
        }
        infolog("Input file created: " + inputFile.getAbsolutePath());

        // Command execution
        cliCmdKeyValPairs.put("INFILE", inputFile.getAbsolutePath());
        long startMillis = System.currentTimeMillis();
        process(cliCmdKeyValPairs, 1);
        long timeMillis = System.currentTimeMillis() - startMillis;
        processing_time = (int) timeMillis;

        //<!-- output_code -->//

        File outputFile = new File(outputFileName);
        if (!outputFile.exists() || outputFile.length() == 0) {
            errorlog("The expected output file " + outputFile.getName() + " is empty or has not been created successfully.");
            return getResult(fac, omNs);
        }
        infolog("Output file of size " + outputFile.length() + " has been created successfully");
        File publicOutputFile =
                new File(publicHttpAccessDir + outputFile.getName());
        if (!new File(publicHttpAccessDir).isDirectory()) {
            errorlog("The output directory " + publicHttpAccessDir + " does not exist. Check "
                    + "publicHttpAccessDir parameter in the service configuration");
            return getResult(fac, omNs);
        }
        infolog("Public output file: " + publicOutputFile.toString());
        try {
            org.apache.commons.io.FileUtils.copyFile(outputFile, publicOutputFile);
        } catch (IOException _) {
            errorlog("An error occurred while trying to copy the result file "
                    + "to the public access directory.");
            return getResult(fac, omNs);
        }
        URL outputFileUrl = null;
        try {
            outputFileUrl = new URL(publicHttpAccessUrl + publicOutputFile.getName());
        } catch (MalformedURLException ex) {
            errorlog("Malformed URL for binary result resource. Verify"
                    + "publicHttpAccessUrl parameter in the "
                    + "resources/services.xml. Exception message: "
                    + ex.getMessage());
            return getResult(fac, omNs);
        }
        infolog("Output URL: " + outputFileUrl.toString());

        // success
        processing_success = true;
        processing_returncode = 0;
        infolog("Service request has been processed successfully");
        OMElement result = getResult(fac, omNs);
        OMElement outputFileElm = fac.createOMElement("outputFile", omNs);
        outputFileElm.setText(String.valueOf(outputFileUrl.toString()));
        result.addChild(outputFileElm);

        return result;
    }

    /**
     *
     * @param fac OMElement factory
     * @param omNs OMNamespace Namespace of the elements created
     * @return Subtree of the result message
     */
    OMElement getResult(OMFactory fac, OMNamespace omNs) {
        OMElement result = fac.createOMElement("result", omNs);
        OMElement success = fac.createOMElement("success", omNs);
        success.setText(String.valueOf(processing_success));
        result.addChild(success);
        OMElement returncode = fac.createOMElement("returncode", omNs);
        returncode.setText(String.valueOf(processing_returncode));
        result.addChild(returncode);
        OMElement message = fac.createOMElement("message", omNs);
        message.setText(String.valueOf(processing_message));
        result.addChild(message);
        OMElement time = fac.createOMElement("time", omNs);
        time.setText(String.valueOf(processing_time));
        result.addChild(time);
        OMElement unitid = fac.createOMElement("unitid", omNs);
        unitid.setText(String.valueOf(processing_unitid));
        result.addChild(unitid);
        OMElement log = fac.createOMElement("log", omNs);
        log.setText(String.valueOf(processing_log));
        result.addChild(log);
        return result;
    }

    /**
     * Get the value of a service parameter defined in the
     * resources/services.xml.
     * @param parm Parameter defined in the services.xml
     * @return Value of the parameter
     */
    private String getValueOfServiceParameter(String parm) {
        MessageContext msgCtx = MessageContext.getCurrentMessageContext();
        Parameter patternParameter = msgCtx.getParameter(parm);
        String ptn = (String) patternParameter.getValue();
        infolog("Parameter " + parm + " from services.xml: " + ptn);
        return ptn;
    }

    /**
     * Informative log
     * @param msg Message
     */
    private void infolog(String msg) {
        processing_log += msg + ".\n";
        processing_message = msg;
        logger.info(msg);
    }

    /**
     * Error log
     * @param msg Message
     */
    private void errorlog(String msg) {
        processing_log += "ERROR: " + msg + ".\n";
        processing_message = "Service request processing ended with an error";
        logger.error(msg);
    }
}
