// DPQA_Prototype.cpp : Defines the entry point for the console application.
//

#include "ImageIO.h"
#include "ImageMetadata.h"
#include "ImageHistogram.h"
#include "Characterization.h"
#include "Comparison.h"

#include <stdio.h>
#include "opencv2/imgproc/imgproc_c.h"
#include <highgui.h>

int main(int argc, char* argv[])
{
	try
	{
		printf("\n\nRun Characterization:\n");
		printf("=====================\n\n");

		Characterization* c = new Characterization();
		
		IplImage* img = ImageIO::loadImage(argv[1]);
		//IplImage* img;

		ImageMetadata* metadata = new ImageMetadata();
		c->addTask(metadata);

		ImageHistogram* hist = new ImageHistogram();
		c->addTask(hist);

		c->execute(img);

		c->writeOutput();

		printf("\n\nRead Data for Comparison:\n");
		printf("=========================\n\n");

		string file1 = "D:\\WORK\\AIT_TFS\\s3ms16.d03.arc.local\\SCAPE\\SCAPE QA\\Debug\\test.xml";
		string file2 = "D:\\WORK\\AIT_TFS\\s3ms16.d03.arc.local\\SCAPE\\SCAPE QA\\Debug\\test2.xml";

		Comparison* comp = new Comparison();
		comp->read(&file1, &file2);
	}
	catch(...)
	{
		printf("Exception while reading image\n");
	}

	return 0;
}


