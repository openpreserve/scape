
#include <stdio.h>
#include <string>

#include "ImageIO.h"
#include "ImageMetadata.h"
#include "ImageHistogram.h"
#include "ImageProfile.h"
#include "Characterization.h"
#include "Comparison.h"
#include "SIFTComparison.h"

#include "opencv2/imgproc/imgproc_c.h"
#include <highgui.h>

#include <tclap/CmdLine.h>

using namespace std;

int main(int argc, char* argv[])
{

	try
	{  
	
		// init comandline parser
			TCLAP::CmdLine cmd("Command description message", ' ', "0.9");

			TCLAP::UnlabeledValueArg<std::string> file1Arg("file", "image file to extract features from", true, "", "file", false);
			cmd.add( file1Arg );

		// init characterization
			Characterization* c     = new Characterization();
	
		// add tasks
	//		ImageMetadata* metadata = new ImageMetadata();
	//		c->addTask(metadata); */

			ImageHistogram* hist    = new ImageHistogram();
			c->addTask(hist);

			ImageProfile* profile   = new ImageProfile();
			c->addTask(profile);

			// SIFTComparison* sift = new SIFTComparison();
			// c->addTask(sift);

		// add task comandline parameters
			c->addCommandLineArgs(&cmd);

		// parse arguments
			cmd.parse( argc, argv );
			c->parseCommandLineArgs();

			string* file1 = &file1Arg.getValue();	

		// execute characterization
			IplImage* img = ImageIO::loadImage(const_cast<char*>(file1->c_str()));
			c->execute(img);

		// output results
			c->writeOutput();
		
	} 
	catch (TCLAP::ArgException &e)  // catch any exceptions
	{
	}

}