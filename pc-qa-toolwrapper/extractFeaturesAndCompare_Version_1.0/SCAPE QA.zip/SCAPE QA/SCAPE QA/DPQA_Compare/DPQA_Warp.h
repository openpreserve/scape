#pragma once

class DPQA_Warp
{
public:

	static void process( string &trainFile, string &queryFile );

};
