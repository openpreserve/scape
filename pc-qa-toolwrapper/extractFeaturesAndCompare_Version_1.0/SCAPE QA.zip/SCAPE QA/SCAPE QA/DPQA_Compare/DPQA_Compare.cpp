
#include <tclap/CmdLine.h>

#include <stdio.h>
#include <string>

#include "Comparison.h"
#include "DPQA_Warp.h"


using namespace std;



int main(int argc, char* argv[])
{

	try
	{  
		// init comandline parser
			TCLAP::CmdLine cmd("Command description message", ' ', "0.9");


			TCLAP::UnlabeledValueArg<std::string> file1Arg("file1", "file 1 that should be compared", true, "", "file1", false);
			cmd.add( file1Arg );

			TCLAP::UnlabeledValueArg<std::string> file2Arg("file2", "file 2 that should be compared", true, "", "file2", false);
			cmd.add( file2Arg );

			TCLAP::ValueArg<int> argLevel("l","level","Comparison Level (1-3)",false,0,"int");
			cmd.add( argLevel );

			TCLAP::SwitchArg argAlign("a","align","Calculate affine transformations to correctly align the two images",false);
			cmd.add( argAlign );

			//TCLAP::SwitchArg test = new TCLAP::SwitchArg()
		// init comparison
			Comparison* comp = new Comparison();

		// add tasks
			comp->addCommandLineArgs(&cmd);

		// parse arguments
			cmd.parse( argc, argv );
			
			string file1 = file1Arg.getValue();
			string file2 = file2Arg.getValue();
			bool   align = argAlign.getValue();


			if (argLevel.getValue() < 3)
			{
				// Level 1 - 2
				// compare xml files
				comp->read(&file1, &file2);
				comp->parseCommandLineArgs();
			}
			else
			{
				// Level 3
				// compare image files
				comp->parseCommandLineArgs();
				comp->level3(&file1, &file2);

				if (align)
				{
					SIFTComparison *sc = new SIFTComparison();
					sc->process(&file1, &file2);
				}
			}

			
		// execute comparison
			comp->execute();

		// output results
			comp->writeOutput();
			

	} 
	catch (TCLAP::ArgException &e)  // catch any exceptions
	{
	}


	
	
	
	
	
	
}