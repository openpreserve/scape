#include <stdio.h>
#include <string>
#include <cstdlib> 

#include <iostream>

#include "ImageIO.h"
#include "ImageMetadata.h"
#include "ImageHistogram.h"
#include "ImageProfile.h"
#include "Characterization.h"
#include "Comparison.h"
#include "SIFTComparison.h"
#include "LoweSIFTMatcher.h"
#include "RobustMatcher.h"

#include "SSIM.h"
#include "UIQI.h"

#include <cv.h>
#include "opencv2/imgproc/imgproc_c.h"
#include <highgui.h>

#include <tclap/CmdLine.h>

using namespace std;
using namespace cv;

double scale1 = 1;
double scale2 = 1;

int MAX_IMAGE_RESOLUTION = 1000000;

Mat downsample(Mat* matImg, double scale)
{
	Mat orImg;

	resize(*matImg,orImg, Size(), scale, scale,INTER_LINEAR);

	return orImg;
}

Mat calculateAffineTransform( vector< DMatch > &matches, vector<KeyPoint> &keypointsTrain, vector<KeyPoint> &keypointsQuery ) 
{

	//cout << "calculate affine matrix" << "\n";

	// Build matrix a
	Mat a((matches.size() * 2), 6, CV_64F);
	Mat b((matches.size() * 2), 1, CV_64F);

	int j = 0;

	for(int i = 0; i < matches.size(); ++i)
	{		
		DMatch match = matches[i];

		Mat M1 = (Mat_<double>(1,6) << keypointsTrain[match.trainIdx].pt.x, keypointsTrain[match.trainIdx].pt.y, 0, 0, 1, 0);
		M1.copyTo(a.row(j));

		M1.release();

		b.at<double>(j,0) = keypointsQuery[match.queryIdx].pt.x;

		j++;

		Mat M2 = (Mat_<double>(1,6) << 0, 0, keypointsTrain[match.trainIdx].pt.x, keypointsTrain[match.trainIdx].pt.y, 0, 1);
		M2.copyTo(a.row(j));

		M2.release();

		b.at<double>(j,0) = keypointsQuery[match.queryIdx].pt.y;

		j++;
	}

	// calculate transformation matrix

	// approximate least squares estimation
	Mat at = a.t() * a;
	at = at.inv() * a.t() * b;

	a.release();
	b.release();
	//cout << at << "\n";

	// re-arrange matrix
	Mat M(2,3,CV_64F);

	// translation matrix
	M.at<double>(0,0) = at.at<double>(0,0);
	M.at<double>(0,1) = at.at<double>(1,0);
	M.at<double>(1,0) = at.at<double>(2,0);
	M.at<double>(1,1) = at.at<double>(3,0);

	// affine matrix
	M.at<double>(0,2) = at.at<double>(4,0);
	M.at<double>(1,2) = at.at<double>(5,0);

	at.release();

	// invert matrix
	invertAffineTransform(M, M);

	return M;
}

Mat calculateTransformWithRansac( Mat matImageTrain, Mat matImageQuery ) 
{

	// downsample image

	// large images may fail to process due to resource limitations (e.g. internal memory)
	if ((matImageTrain.rows * matImageTrain.cols) > MAX_IMAGE_RESOLUTION)
	{
		// downsample images to approximately 1M-pixels

		// downsample image 1

		scale1 = 1/sqrt((double)(((double)matImageTrain.rows * (double)matImageTrain.cols) / (double)MAX_IMAGE_RESOLUTION));

		cout << "downsample image 1" << "\n";
		cout << "orig: " << matImageTrain.rows << ", " << matImageTrain.cols << "\n";
		cout << "scale1: " << scale1 << "\n";

		matImageTrain = downsample(&matImageTrain, scale1);

		cout << "new dim: " << matImageTrain.rows << ", " << matImageTrain.cols << "\n";

		// downsample image 2

		// downsample image to approx. 1M-pixels
		scale2 = 1/sqrt((double)(((double)matImageQuery.rows * (double)matImageQuery.cols) / (double)MAX_IMAGE_RESOLUTION));

		cout << "downsample image 2" << "\n";
		cout << "orig: " << matImageQuery.rows << ", " << matImageQuery.cols << "\n";
		cout << "scale2: " << scale2 << "\n";

		matImageQuery = downsample(&matImageQuery, scale2);

		cout << "new dim: " << matImageQuery.rows << ", " << matImageQuery.cols << "\n";
	}

	// extract keypoints

	cout << "extract keypoints" << "\n";

	SurfFeatureDetector*     featureDetector     = new SurfFeatureDetector();
	SurfDescriptorExtractor* descriptorExtractor = new SurfDescriptorExtractor();

	vector<KeyPoint> keypointsTrain;
	vector<KeyPoint> keypointsQuery;

	featureDetector->detect( matImageTrain, keypointsTrain );
	featureDetector->detect( matImageQuery, keypointsQuery );

	cout << "keypoints1 = " << keypointsTrain.size() << "\n";
	cout << "keypoints2 = " << keypointsQuery.size() << "\n";

	delete featureDetector;

	// calculate descriptors

	cout << "calculate descriptors" << "\n";

	Mat descriptorsTrain;
	Mat descriptorsQuery;

	descriptorExtractor->compute( matImageTrain, keypointsTrain, descriptorsTrain );
	descriptorExtractor->compute( matImageQuery, keypointsQuery, descriptorsQuery );

	delete descriptorExtractor;

	// match keypoints

	cout << "match descriptors" << "\n";

	//LoweSIFTMatcher matcher;

	RobustMatcher matcher;
	vector<DMatch> good_matches;

	matcher.match(keypointsQuery, keypointsTrain, descriptorsQuery, descriptorsTrain, good_matches );

	cout << good_matches.size() << " matches\n";
	
	Mat M = calculateAffineTransform(good_matches, keypointsTrain, keypointsQuery);

	// re-scale affine matrix

	M.at<double>(0,0) = M.at<double>(0,0) / (scale1 / scale2);
	M.at<double>(0,1) = M.at<double>(0,1) / (scale1 / scale2);
	M.at<double>(1,0) = M.at<double>(1,0) / (scale1 / scale2);
	M.at<double>(1,1) = M.at<double>(1,1) / (scale1 / scale2);

	M.at<double>(0,2) = M.at<double>(0,2) / scale1;
	M.at<double>(1,2) = M.at<double>(1,2) / scale1;

	cout << "scaled affine matrix:\n";
	cout << "  " << M << "\n";

	return M;
}

void process( string* trainFile, string* queryFile ) 
{
	cout << "loading images" << "\n";

	IplImage* trainImage = cvLoadImage( (const_cast<char*>(trainFile->c_str())), CV_LOAD_IMAGE_COLOR );
	IplImage* queryImage = cvLoadImage( (const_cast<char*>(queryFile->c_str())), CV_LOAD_IMAGE_COLOR );

	Mat matImageTrainOrig(trainImage);
	Mat matImageQueryOrig(queryImage);

	//delete trainImage, queryImage;

	Mat M = calculateTransformWithRansac(matImageTrainOrig, matImageQueryOrig);

	// warp image

	cout << "warp" << "\n";

	Mat dst(matImageTrainOrig.size(),matImageTrainOrig.type());
	warpAffine(matImageQueryOrig,dst,M,matImageTrainOrig.size(),INTER_LINEAR,BORDER_CONSTANT,0);

	//matImageQueryOrig.release();

	// calculate Structured Similarity (SSIM)

	cout << "SSIM (no mask) = " << SSIM::calcSSIM(matImageTrainOrig, dst,-1) << "\n";

	// create mask
	Mat dstMask(matImageTrainOrig.size(),CV_8U);
	Mat queryMask = Mat::ones(matImageQueryOrig.size(),CV_8U);

	warpAffine(queryMask,dstMask,M,matImageTrainOrig.size(),INTER_NEAREST,BORDER_CONSTANT,0);

	cout << "SSIM (with mask) = " << SSIM::calcSSIM(matImageTrainOrig, dst,-1,CV_BGR2YUV, dstMask) << "\n";

	imwrite("test.mask.png",dstMask);


	// write images to disk

	cout << "save" << "\n";

	imwrite("test.out.png",dst);

	Mat diff(matImageTrainOrig.size(),matImageTrainOrig.type());
	absdiff(matImageTrainOrig, dst, diff);

	cout << "save diff" << "\n";

	imwrite("test.diff.png",diff);

	Mat dstMask2(matImageTrainOrig.size(),matImageQueryOrig.type());
	Mat queryMask2 = Mat::ones(matImageQueryOrig.size(),matImageQueryOrig.type());
	queryMask2.setTo(1);

	warpAffine(queryMask2,dstMask2,M,matImageTrainOrig.size(),INTER_NEAREST,BORDER_CONSTANT,0);

	multiply(matImageTrainOrig, dstMask2, matImageTrainOrig);

	imwrite("test.train.masked.png",matImageTrainOrig);

	absdiff(matImageTrainOrig, dst, diff);

	absdiff(diff,255,diff);


	imwrite("test.diff2.png",diff);
}


int main(int argc, char* argv[])
{

	try
	{  
		// init comandline parser

			cout << "parsing cmd arguments" << "\n";

			TCLAP::CmdLine cmd("Command description message", ' ', "0.9");

			TCLAP::UnlabeledValueArg<std::string> trainFileArg("trainFile", "image1 file to extract features from", true, "", "file", false);
			TCLAP::UnlabeledValueArg<std::string> queryFileArg("queryFile", "image2 file to extract features from", true, "", "file", false);

			cmd.add( trainFileArg );
			cmd.add( queryFileArg );

		// parse arguments

			cmd.parse( argc, argv );

			string* trainFile = &trainFileArg.getValue();
			string* queryFile = &queryFileArg.getValue();

		// load images

			process(trainFile, queryFile);

	} 
	catch (TCLAP::ArgException &e)  // catch any exceptions
	{
	}

}

