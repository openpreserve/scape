#pragma once



public class DPQA_Warp
{
public:

	static void process( string* trainFile, string* queryFile );

};
