#pragma once
// Mandatory for using any feature of Xerces.
#include "xercesc/util/PlatformUtils.hpp"


// DOM (if you want SAX, then that's a different include)
#include "xercesc/dom/DOM.hpp"


// Define namespace symbols (Otherwise we'd have to prefix Xerces code with 
// "XERCES_CPP_NAMESPACE::")
XERCES_CPP_NAMESPACE_USE

class XercesTest
{
public:
	XercesTest(void);
	~XercesTest(void);

	void helloWorld(void);
};
