#pragma once

#include "stdafx.h"

#include <string>
#include <list>

#include "Level2Feature.h"
#include "MatOutputParameter.h"
#include "DoubleOutputParameter.h"
#include "StringConverter.h"
#include "XMLUtils.h"

#include <highgui.h>
#include "opencv2/imgproc/imgproc_c.h"

#include <xercesc/dom/DOM.hpp>
#include <xercesc/dom/DOMElement.hpp>

#include <stdio.h>
#include <cv.h>

#include <tclap/CmdLine.h>

using namespace cv;
using namespace xercesc;
using namespace std;


class ImageHistogram :
	public Level2Feature
{
private:
	int    binSize;
	string metric;

	list<Mat> bins;
	void loadData(DOMElement* currentElement);
	void normalizeHist(Mat hist, int size);

protected:
	using Feature::name;

public:
	static const string TASK_NAME;
	static const string TAG_BINS;

	ImageHistogram(DOMElement* elem);
	ImageHistogram(void);
	~ImageHistogram(void);

	// implement virtual methods
	void   execute(IplImage* image);
	double compare(Feature *task);
	void parseCommandlineArguments();
	list<string>* getCmdlineArguments(void);
	void setCmdlineArguments(list<string>* args);

	list<Mat> getBins(void);

};
