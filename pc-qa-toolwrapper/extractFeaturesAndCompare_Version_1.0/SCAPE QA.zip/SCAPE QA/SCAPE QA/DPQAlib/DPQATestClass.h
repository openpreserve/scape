#pragma once

#include <stdio.h>

class DPQATestClass
{
public:
	DPQATestClass(void);
	~DPQATestClass(void);

	void helloWorld(void);
};
