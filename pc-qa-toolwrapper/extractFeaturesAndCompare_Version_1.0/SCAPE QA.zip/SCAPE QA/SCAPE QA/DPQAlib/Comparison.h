#pragma once

#include "stdafx.h"

#include "ImageIO.h"
#include "XMLReader.h"
#include "Feature.h"
#include "PixelwiseComparison.h"
#include "SIFTComparison.h"

#include "ImageProfile.h"

#include "opencv2/imgproc/imgproc_c.h"
#include <highgui.h>

#include <tclap/CmdLine.h>

#include <string>
#include <list>

using namespace cv;
using namespace std;

class Comparison
{
private:
	list<Feature*> tasks;

	list<Feature*> tasksFromXML1;
	list<Feature*> tasksFromXML2;

	void setCommandlineArguments(Feature* task);
	void setXmlTasksCmdArgs(list<Feature*>* tasks);

public:
	Comparison(void);
	~Comparison(void);

	void read(string* filename1, string* filename2);
	void addCommandLineArgs(TCLAP::CmdLine* cmd);
	void parseCommandLineArgs();
	void execute();
	void level3(string *filename1, string *filename2);

	void writeOutput(void);
};
