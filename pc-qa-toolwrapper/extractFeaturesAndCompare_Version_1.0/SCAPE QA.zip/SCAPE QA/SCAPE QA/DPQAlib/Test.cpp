#include "Test.h"

Test123::Test123(void)
{
}

Test123::~Test123(void)
{
}

double Test123::test1(void)
{
	return 123;
}