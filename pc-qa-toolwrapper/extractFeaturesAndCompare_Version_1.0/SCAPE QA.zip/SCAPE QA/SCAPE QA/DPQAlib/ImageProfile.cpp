#include "ImageProfile.h"

const string ImageProfile::TASK_NAME = "ImageProfile";


ImageProfile::ImageProfile(DOMElement* elem):Level2Feature(elem)
{
	name = TASK_NAME;
	loadData(elem);
}

ImageProfile::ImageProfile(void):Level2Feature()
{
	name = TASK_NAME;
}

ImageProfile::~ImageProfile(void)
{
}

void ImageProfile::parseCommandlineArguments()
{
}

void ImageProfile::execute(IplImage* image)
{
	// for each channel
	IplImage* rPlane = cvCreateImage( cvGetSize( image ), 8, 1);
	IplImage* gPlane = cvCreateImage( cvGetSize( image ), 8, 1);
	IplImage* bPlane = cvCreateImage( cvGetSize( image ), 8, 1);

	IplImage* planes[] = {rPlane, gPlane, bPlane};
	cvSplit( image, rPlane, gPlane, bPlane, NULL );

	
	for (int i = 0; i < 3; i++)
	{
		Mat mtx(planes[i]);

		list<double> vertProfile;
		Scalar sum = 0;

		// create profile for each col
		for(int c = 0; c < mtx.cols; c++)
		{
			Mat col = mtx.col(c);

			Scalar s = mean(col);

			sum.val[0] += s.val[0];

			vertProfile.push_back(s.val[0]);			
		}

		// normalize profile
		list<double>::iterator pelem;
		for( pelem = vertProfile.begin(); pelem != vertProfile.end(); ++pelem) *pelem /= sum.val[0]; 
	

		ListOutputParameter* vParam = new ListOutputParameter("projection");
		vParam->setData(vertProfile);
		vParam->addAttribute(*new OutputAttribute(*new string("orientation"),*new string("vertical")));
		vParam->addAttribute(*new OutputAttribute(*new string("channel"),StringConverter::toString(i)));
		addOutputParameter(*vParam);

		list<double> horProfile;

		sum.val[0] = 0;
		// create profile for each row
		for(int r = 0; r < mtx.rows; r++)
		{
			Mat row = mtx.row(r);

			Scalar s = mean(row);
			
			sum.val[0] += s.val[0];

			horProfile.push_back(s.val[0]);
		}

		// normalize profile		
		for( pelem = horProfile.begin(); pelem != horProfile.end(); ++pelem) *pelem /= sum.val[0]; 

		ListOutputParameter* hParam = new ListOutputParameter("projection");
		hParam->setData(vertProfile);
		hParam->addAttribute(*new OutputAttribute(*new string("orientation"),*new string("horizontal")));
		hParam->addAttribute(*new OutputAttribute(*new string("channel"),StringConverter::toString(i)));
		addOutputParameter(*hParam);
	}
	
}

void ImageProfile::loadData(DOMElement* currentElement)
{
	if (currentElement->hasChildNodes())
	{
		DOMNodeList* children = currentElement->getChildNodes();
		const  XMLSize_t nodeCount = children->getLength();

		for( XMLSize_t i = 0; i < nodeCount; ++i )
		{
			DOMNode* currentNode = children->item(i);
			DOMElement* elem = dynamic_cast< xercesc::DOMElement* >( currentNode );	
			
			if( currentNode->getNodeType() &&  // true is not NULL
				currentNode->getNodeType() == DOMNode::ELEMENT_NODE ) // is element
			{
				Mat m1 = StringConverter::toMat(&XMLUtils::getElementValue(elem));
				profiles.push_back(m1);
			}
		}
	}
}

double ImageProfile::compare(Feature *task)
{
	list<Mat> otherProfiles = ((ImageProfile*)task)->getProfiles();

	double dist = 0;

	int size = otherProfiles.size();
	for (int i = 0; i < size; i++)
	{
		Mat m1 = profiles.front();
		Mat m2 = otherProfiles.front();


		int method = CV_COMP_CHISQR;
					
		/*if(metric.compare("CV_COMP_CORREL") == 0)
		{
			method = CV_COMP_CORREL;
		}
		else if(metric.compare("CV_COMP_INTERSECT") == 0)
		{
			method = CV_COMP_INTERSECT;
		}
		else if(metric.compare("CV_COMP_BHATTACHARYYA") == 0)
		{
			method = CV_COMP_BHATTACHARYYA;
		}*/

		dist += compareHist(m1, m2, method);

		profiles.pop_front();
		otherProfiles.pop_front();
	}

	DoubleOutputParameter *param1 = new DoubleOutputParameter("result");
	param1->setData(dist / size);
	addOutputParameter(*param1);

	return dist / size;
}

list<string>* ImageProfile::getCmdlineArguments(void)
{
	return NULL;
}

void ImageProfile::setCmdlineArguments(list<string>* args)
{
}

list<Mat> ImageProfile::getProfiles(void)
{
	return profiles;
}