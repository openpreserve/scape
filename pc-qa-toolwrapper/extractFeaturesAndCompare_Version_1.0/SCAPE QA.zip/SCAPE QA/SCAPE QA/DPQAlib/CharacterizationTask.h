#pragma once

#include "stdafx.h"

#include <list>
#include <string>
#include <stdio.h>

#include <xercesc/dom/DOMElement.hpp>
#include "opencv2/imgproc/imgproc_c.h"

#include <tclap/CmdLine.h>
#include <tclap/Arg.h>

#include "OutputParameter.h"
#include "OutputAttribute.h"

using namespace xercesc;
using namespace std;

class CharacterizationTask
{
private:
	list<OutputParameter> outputParams;
	list<TCLAP::Arg*> characterizationArguments;
	list<TCLAP::Arg*> comparisonArguments;

protected:
	string    name;
	int       level;

public:
	static const string TAG_NAME;
	static const string ATTR_LEVEL;
	static const string ATTR_NAME;

	// constructors / destructors
	CharacterizationTask(DOMElement* elem);
	CharacterizationTask(void);
	~CharacterizationTask(void);

	// virtual methods
	virtual void execute(IplImage* image)                = 0;
	virtual double compare(CharacterizationTask* task)   = 0;
	virtual void parseCommandlineArguments()             = 0;
	virtual list<string>* getCmdlineArguments(void)      = 0;
	virtual void setCmdlineArguments(list<string>* args) = 0;

	void addOutputParameter(OutputParameter param);
	list<OutputParameter> *getOutputParameters();

	void addCharacterizationCommandlineArgument(TCLAP::Arg* arg);
	void addComparisonCommandlineArgument(TCLAP::Arg* arg);
	list<TCLAP::Arg*> *getCharacterizationCommandlineArguments();
	list<TCLAP::Arg*> *getComparisonCommandlineArguments();

	string getName(void);
	int getLevel(void);

	void testOutput(void);

	

};