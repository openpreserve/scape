
#define INT     0
#define FLOAT   1
#define STRING  2

virtual class OutputType
{

public:
	enum {INT,FLOAT,STRING};
}