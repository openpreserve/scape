#include "Level1Characterization.h"

Level1Characterization::Level1Characterization(IplImage* img):Characterization(img)
{
}

Level1Characterization::~Level1Characterization(void)
{
}
