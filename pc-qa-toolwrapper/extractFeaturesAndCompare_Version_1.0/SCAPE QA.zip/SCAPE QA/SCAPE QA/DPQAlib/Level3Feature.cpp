#include "Level3Feature.h"




Level3Feature::Level3Feature(void):Feature()
{
	level = 3;
}

Level3Feature::~Level3Feature(void)
{
}