#pragma once

class Test123
{
public:
	Test123(void);
	~Test123(void);

	double test1(void);
};
