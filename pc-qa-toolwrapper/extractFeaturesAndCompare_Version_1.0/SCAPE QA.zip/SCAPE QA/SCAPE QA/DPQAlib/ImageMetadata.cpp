#include "ImageMetadata.h"


const string ImageMetadata::TASK_NAME      = "ImageMetadata";
const string ImageMetadata::IMAGE_WIDTH    = "ImageWidth";
const string ImageMetadata::IMAGE_HEIGHT   = "ImageHeight";
const string ImageMetadata::IMAGE_CHANNELS = "ImageChannels";


ImageMetadata::ImageMetadata(DOMElement* elem):Level1Feature(elem)
{
	name = TASK_NAME;
	loadData(elem);
}

ImageMetadata::ImageMetadata(void):Level1Feature()
{
	name = TASK_NAME;
}

ImageMetadata::~ImageMetadata(void)
{
}

void ImageMetadata::execute(IplImage* image)
{
	IntOutputParameter* param1 =  new IntOutputParameter(IMAGE_WIDTH);
	param1->setData(image->width);
	addOutputParameter(*param1);

	IntOutputParameter* param2 =  new IntOutputParameter(IMAGE_HEIGHT);
	param2->setData(image->height);
	addOutputParameter(*param2);

	IntOutputParameter* param3 =  new IntOutputParameter(IMAGE_CHANNELS);
	param3->setData(image->nChannels);
	addOutputParameter(*param3);
}

void ImageMetadata::loadData(DOMElement* currentElement)
{
	imageWidth    = StringConverter::toInt(&XMLUtils::getElementValue(currentElement,&IMAGE_WIDTH));
	imageHeight   = StringConverter::toInt(&XMLUtils::getElementValue(currentElement,&IMAGE_HEIGHT));
	imageChannels = StringConverter::toInt(&XMLUtils::getElementValue(currentElement,&IMAGE_CHANNELS));
}

double ImageMetadata::compare(Feature *task)
{
	double result = 0;

	ImageMetadata* im = dynamic_cast< ImageMetadata* >( task );
	
	result += (im->imageHeight - this->imageHeight);
	result += (im->imageWidth - this->imageWidth);
	result += (im->imageChannels - this->imageChannels);

	DoubleOutputParameter *param1 = new DoubleOutputParameter("result");
	param1->setData(result);
	addOutputParameter(*param1);

	return result;
}

void ImageMetadata::parseCommandlineArguments()
{
}

list<string>* ImageMetadata::getCmdlineArguments(void)
{
	return NULL;
}

void ImageMetadata::setCmdlineArguments(list<string>* args)
{
}