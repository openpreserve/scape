#pragma once

#include "stdafx.h"

#include "Feature.h"

#include <xercesc/dom/DOMElement.hpp>

using namespace xercesc;

class Level1Feature : 
	public Feature
{
protected:
	using Feature::level;

public:
	Level1Feature(DOMElement* elem);
	Level1Feature(void);
	~Level1Feature(void);
};
