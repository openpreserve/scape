#pragma once

#include "stdafx.h"

#include "CharacterizationTask.h"

#include <xercesc/dom/DOMElement.hpp>

using namespace xercesc;

class Level2CharacterizationTask :
	public CharacterizationTask
{
protected:
	using CharacterizationTask::level;

public:
	Level2CharacterizationTask(DOMElement* elem);
	Level2CharacterizationTask(void);
	~Level2CharacterizationTask(void);
};
