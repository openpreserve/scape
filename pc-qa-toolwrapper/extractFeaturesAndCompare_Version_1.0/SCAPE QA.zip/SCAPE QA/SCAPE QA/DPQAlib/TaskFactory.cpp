#include "TaskFactory.h"

TaskFactory::TaskFactory(void)
{
}

TaskFactory::~TaskFactory(void)
{
}

Feature* TaskFactory::createTask(DOMElement* elem)
{
	string name = extractName(elem);
	

	if (name.compare(ImageMetadata::TASK_NAME) == 0)
	{
		return new ImageMetadata(elem);
	}
	else if (name.compare(ImageHistogram::TASK_NAME) == 0)
	{
		return new ImageHistogram(elem);
	}
	else if (name.compare(ImageProfile::TASK_NAME) == 0)
	{
		return new ImageProfile(elem);
	}
	else if (name.compare(SIFTComparison::TASK_NAME) == 0)
	{
		return new SIFTComparison(elem);
	}
}

string TaskFactory::extractName(DOMElement* elem)
{
	XMLCh* ATTR_ImageWidth    = XMLString::transcode(Feature::ATTR_NAME.c_str());

	const XMLCh* xml_name = elem->getAttribute(ATTR_ImageWidth);
	return XMLString::transcode(xml_name);
}
