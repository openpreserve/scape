#include "StringOutputParameter.h"

StringOutputParameter::StringOutputParameter(string nme):OutputParameter(nme)
{
}

StringOutputParameter::~StringOutputParameter(void)
{
}
