#pragma once

#include "stdafx.h"

#include "CharacterizationTask.h"

#include <xercesc/dom/DOMElement.hpp>

using namespace xercesc;

class Level1CharacterizationTask : 
	public CharacterizationTask
{
protected:
	using CharacterizationTask::level;

public:
	Level1CharacterizationTask(DOMElement* elem);
	Level1CharacterizationTask(void);
	~Level1CharacterizationTask(void);
};
