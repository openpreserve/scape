#pragma once

#include "stdafx.h"

#include <string>

#include "ImageMetadata.h"
#include "ImageHistogram.h"
#include "ImageProfile.h"
#include "SIFTComparison.h"

#include <xercesc/dom/DOM.hpp>
#include <xercesc/dom/DOMElement.hpp>

using namespace std;
using namespace xercesc;

class TaskFactory
{
private:
	static string extractName(DOMElement* elem);

public:
	TaskFactory(void);
	~TaskFactory(void);
	static Feature* createTask(DOMElement* elem);
	static void copyCmdlineArgument(Feature* src, Feature* dest);
};
