#pragma once

#include "stdafx.h"

#include <string>
#include <list>

#include "Level2Feature.h"
#include "ListOutputParameter.h"
#include "DoubleOutputParameter.h"
#include "StringConverter.h"
#include "XMLUtils.h"

#include <highgui.h>
#include "opencv2/imgproc/imgproc_c.h"

#include <xercesc/dom/DOM.hpp>
#include <xercesc/dom/DOMElement.hpp>

#include <stdio.h>
#include <cv.h>

#include <tclap/CmdLine.h>

using namespace cv;
using namespace xercesc;
using namespace std;

class ImageProfile :
	public Level2Feature
{
private:
	list<Mat> profiles;

	void loadData(DOMElement* currentElement);

protected:
	using Feature::name;

public:
	static const string TASK_NAME;

	ImageProfile(DOMElement* elem);
	ImageProfile(void);
	~ImageProfile(void);

	// implement virtual methods
	void   execute(IplImage* image);
	double compare(Feature *task);
	void parseCommandlineArguments();
	list<string>* getCmdlineArguments(void);
	void setCmdlineArguments(list<string>* args);

	list<Mat> getProfiles(void);
};
