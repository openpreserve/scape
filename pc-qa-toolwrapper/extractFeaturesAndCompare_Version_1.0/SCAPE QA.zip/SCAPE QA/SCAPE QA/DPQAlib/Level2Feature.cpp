#include "Level2Feature.h"

Level2Feature::Level2Feature(DOMElement* elem):Feature(elem)
{
	level = 2;
}

Level2Feature::Level2Feature(void):Feature()
{
	level = 2;
}

Level2Feature::~Level2Feature(void)
{
}
