#pragma once

#include "stdafx.h"

#include <string>
#include <list>

#include "Level3Feature.h"
#include "DoubleOutputParameter.h"

#include <highgui.h>
#include "opencv2/imgproc/imgproc_c.h"


using namespace cv;
using namespace std;

class PixelwiseComparison :
	public Level3Feature
{
private:
	IplImage *image;

public:
	static const string TASK_NAME;

	PixelwiseComparison(void);
	~PixelwiseComparison(void);

	// implement virtual methods
	void execute(IplImage* image);
	double compare(Feature *task);
	void parseCommandlineArguments();
	list<string>* getCmdlineArguments(void);
	void setCmdlineArguments(list<string>* args);

	IplImage *getImage(void);
};
