#include "ImageHistogram.h"


const string ImageHistogram::TASK_NAME = "ImageHistogram";
const string ImageHistogram::TAG_BINS   = "bins";

TCLAP::ValueArg<int> argBinSize("","numbins","[ImageHistogram] Number of histogram bins",false,256,"int");
TCLAP::ValueArg<string> argMetric("","metric","[ImageHistogram] Metric for histogram comparison (CV_COMP_CHISQR,CV_COMP_CORREL,CV_COMP_INTERSECT,CV_COMP_BHATTACHARYYA)",false,"CV_COMP_CHISQR","str");

ImageHistogram::ImageHistogram(DOMElement* elem):Level2Feature(elem)
{
	name = TASK_NAME;
	loadData(elem);
}

ImageHistogram::ImageHistogram(void):Level2Feature()
{
	name = TASK_NAME;

	// add commandline arguments
	addCharacterizationCommandlineArgument(&argBinSize);
	addComparisonCommandlineArgument(&argMetric);
}

ImageHistogram::~ImageHistogram(void)
{
}

void ImageHistogram::parseCommandlineArguments()
{
	binSize = argBinSize.getValue();
	metric  = argMetric.getValue();
}

void ImageHistogram::execute(IplImage* image)
{
	
    int rbins = binSize, gbins = binSize, bbins = binSize;
    int histSize[]  = {rbins, gbins, bbins};
    float rRanges[] = {0, 255}, gRanges[] = {0, 255}, bRanges[] = {0, 255};
	const float* ranges[] = { rRanges, gRanges, bRanges };		
	int channels[] = {0, 1, 2};

	string* sbin   = new string("bins");
	string* sdim   = new string("dimension");
	string* snum   = new string("numberofbins");
	string* srange = new string("range");

    MatND hist;
    
	IplImage* rPlane = cvCreateImage( cvGetSize( image ), 8, 1);
	IplImage* gPlane = cvCreateImage( cvGetSize( image ), 8, 1);
	IplImage* bPlane = cvCreateImage( cvGetSize( image ), 8, 1);

	IplImage* planes[] = {rPlane, gPlane, bPlane};
	cvSplit( image, rPlane, gPlane, bPlane, NULL );

	for (int i = 0; i < 3; i++)
	{
		Mat planeMat = Mat(planes[i],false);
		string ichar = StringConverter::toString((i+1));

		// create histogram for channel i
		calcHist( &planeMat, 1, channels, Mat(), hist, 1, histSize, ranges, true, false );

		normalizeHist(hist, (planeMat.rows * planeMat.cols));
		
		MatOutputParameter* param = new MatOutputParameter(TAG_BINS);
		param->setData(hist.col(0));
		param->addAttribute(*new OutputAttribute(*sdim,*new string(ichar.c_str())));
		
		// range
		stringstream ss1;
		ss1 << histSize[i];
		param->addAttribute(*new OutputAttribute(*snum,ss1.str()));
		
		// range
		stringstream ss2;
		ss2 << ranges[i][0] << "," << ranges[i][1];
		param->addAttribute(*new OutputAttribute(*srange,ss2.str()));
		addOutputParameter(*param);
	}
}

void ImageHistogram::normalizeHist(Mat hist, int size)
{
	for( int i = 0; i < hist.rows; i++ )
    {
		hist.at<float>(i) = hist.at<float>(i) / size;
    }
}

void ImageHistogram::loadData(DOMElement* currentElement)
{
	if (currentElement->hasChildNodes())
	{
		DOMElement* firstChildElem = currentElement->getFirstElementChild();

		Mat red   = StringConverter::toMat(&XMLUtils::getElementValue(firstChildElem));
		bins.push_back(red);		

		DOMElement* nextChildElem = firstChildElem->getNextElementSibling();
		Mat green = StringConverter::toMat(&XMLUtils::getElementValue(nextChildElem));
		bins.push_back(green);

		nextChildElem = firstChildElem->getNextElementSibling();
		Mat blue  = StringConverter::toMat(&XMLUtils::getElementValue(nextChildElem));
		bins.push_back(blue);
	}	
}

double ImageHistogram::compare(Feature *task)
{
	list<Mat> otherBins = ((ImageHistogram*)task)->getBins();

	double dist = 0;

	int channels = bins.size();
	for (int i = 0; i < channels; i++)
	{
		Mat m1 = bins.front();
		Mat m2 = otherBins.front();


		int method = CV_COMP_CHISQR;
					
		if(metric.compare("CV_COMP_CORREL") == 0)
		{
			method = CV_COMP_CORREL;
		}
		else if(metric.compare("CV_COMP_INTERSECT") == 0)
		{
			method = CV_COMP_INTERSECT;
		}
		else if(metric.compare("CV_COMP_BHATTACHARYYA") == 0)
		{
			method = CV_COMP_BHATTACHARYYA;
		}

		dist += compareHist(m1, m2, method);

		bins.pop_front();
		otherBins.pop_front();
	}

	DoubleOutputParameter *param1 = new DoubleOutputParameter("result");
	param1->setData(dist / channels);
	addOutputParameter(*param1);

	return dist / channels;
}

list<Mat> ImageHistogram::getBins(void)
{
	return bins;
}

list<string>* ImageHistogram::getCmdlineArguments(void)
{
	list<string>* result = new list<string>;
	result->push_back(StringConverter::toString(binSize));
	result->push_back(metric);

	return result;
}

void ImageHistogram::setCmdlineArguments(list<string>* args)
{
	binSize = StringConverter::toInt(&args->front());
	metric  = args->back();
}