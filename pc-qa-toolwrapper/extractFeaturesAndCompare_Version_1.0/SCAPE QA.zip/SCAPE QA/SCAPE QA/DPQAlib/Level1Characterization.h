#pragma once

#include "Characterization.h"

class Level1Characterization:public Characterization
{
public:
	Level1Characterization(IplImage* image);
	~Level1Characterization(void);
};
