#include "Level2CharacterizationTask.h"

Level2CharacterizationTask::Level2CharacterizationTask(DOMElement* elem):CharacterizationTask(elem)
{
	level = 2;
}

Level2CharacterizationTask::Level2CharacterizationTask(void):CharacterizationTask()
{
	level = 2;
}

Level2CharacterizationTask::~Level2CharacterizationTask(void)
{
}
