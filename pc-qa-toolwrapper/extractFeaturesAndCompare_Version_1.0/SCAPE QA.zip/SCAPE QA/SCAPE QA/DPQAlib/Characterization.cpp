#include "Characterization.h"

TCLAP::SwitchArg argLevel1("","l1","Include all features of level 1",false);
TCLAP::SwitchArg argLevel2("","l2","Include all features of level 2",false);
TCLAP::MultiArg<string> argNO("n","no","exclude feature from extraction (ImageHistogram, ImageMetdata, ImageProfile)", false, "string");


Characterization::Characterization(void)
{
}

Characterization::~Characterization(void)
{
}

void Characterization::addTask(Feature* task)
{
	tasks.push_back(task);
}

void Characterization::execute(IplImage* img)
{
	list<Feature*>::iterator i;

	for(i=tasks.begin(); i != tasks.end(); ++i)
	{
		Feature* task = *i;

		if(canExecute(task))
		{
			task->execute(img);
		}
	}
}

void Characterization::writeOutput(void)
{
	printf("<?xml version=\"1.0\"?>\n");
	printf("<characterization>\n");

	list<Feature*>::iterator i;

	for(i=tasks.begin(); i != tasks.end(); ++i)
	{
		Feature* task = *i;

		if(canExecute(task))
		{
			printf("<%s %s=\"%d\" %s=\"%s\">\n",Feature::TAG_NAME.c_str(), Feature::ATTR_LEVEL.c_str(), task->getLevel(), Feature::ATTR_NAME.c_str(), task->getName().c_str());
			task->testOutput();
			printf("</%s>\n",Feature::TAG_NAME.c_str());
		}
	}

	printf("</characterization>\n");
}

bool Characterization::canExecute(Feature* task)
{
	bool result = true;

	if( ((task->getLevel() == 1) && (argLevel1.getValue())) ||
		((task->getLevel() == 2) && (argLevel2.getValue())) ||
		((!argLevel1.getValue()) && (!argLevel2.getValue())) )
	{
		vector<string> nos = argNO.getValue();
		
		vector<string>::iterator i;

		for(i=nos.begin(); i != nos.end(); ++i)
		{
			string no = *i;

			if (no.compare(task->getName()) == 0)
			{
				result = false;
			}
		}
	}
	else
	{
		result = false;
	}

	return result;
}

void Characterization::addCommandLineArgs(TCLAP::CmdLine *cmd)
{
	cmd->add(argLevel1);
	cmd->add(argLevel2);
	cmd->add(argNO);

	list<Feature*>::iterator i;

	for(i=tasks.begin(); i != tasks.end(); ++i)
	{
		Feature* task = *i;

		list<TCLAP::Arg*>* args = task->getCharacterizationCommandlineArguments();

		list<TCLAP::Arg*>::iterator j;

		for(j=args->begin(); j != args->end(); ++j)
		{
			TCLAP::Arg* arg = *j;
			cmd->add(arg);
		}
	}
}

void Characterization::parseCommandLineArgs()
{
	list<Feature*>::iterator i;

	for(i=tasks.begin(); i != tasks.end(); ++i)
	{
		Feature* task = *i;
		task->parseCommandlineArguments();
	}
}