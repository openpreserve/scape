#pragma once

#include "stdafx.h"

#include <string>
#include <math.h>

#include "Level2Feature.h"
#include "Mat2DOutputParameter.h"
#include "DoubleOutputParameter.h"
#include "KeyPointOutputParameter.h"

#include "StringConverter.h"
#include "XMLUtils.h"

#include <cv.h>
#include "opencv2/imgproc/imgproc_c.h"
#include <highgui.h>

#include <xercesc/dom/DOM.hpp>
#include <xercesc/dom/DOMElement.hpp>

#include "RobustMatcher.h"
#include "SSIM.h"


using namespace cv;
using namespace xercesc;
using namespace std;


class SIFTComparison :
	public Level2Feature
{

private:
	IplImage *image;
	Mat descriptors;
	vector<KeyPoint> keypoints;
	double scale;

	void loadDescriptors(DOMElement* elem);
	void loadKeyPoints(DOMElement* elem);
	void loadData(DOMElement* currentElement);
	vector<DMatch> calcGoodMatches(vector<DMatch> matches);
	Mat calcAffineTransform(vector<DMatch> goodMatches, vector<KeyPoint> keypointsQuery, vector<KeyPoint> keypointsTrain, double scale2);
	Mat downsample(Mat* matImg);

	// from DPQA
	double scale1;
	double scale2;

	Mat downsample(Mat* matImg, double scale);
	Mat calculateAffineTransform( vector< DMatch > &matches, vector<KeyPoint> &keypointsTrain, vector<KeyPoint> &keypointsQuery ) ;
	Mat calculateTransformWithRansac( Mat matImageTrain, Mat matImageQuery ); //TODO: Rename

protected:
	using Feature::name;

public:
	static const string TASK_NAME;
	static const string TAG_DESCRIPTORS;
	static const string TAG_KEYPOINTS;
	static const string ATTR_DATFILE_MAT;
	static const string TAG_SCALE;

	static const int MAX_IMAGE_RESOLUTION = 1000000;

	SIFTComparison(DOMElement* elem);
	SIFTComparison(void);
	~SIFTComparison(void);

	// implement virtual methods
	void execute(IplImage* image);
	double compare(Feature *task);
	void parseCommandlineArguments();
	list<string>* getCmdlineArguments(void);
	void setCmdlineArguments(list<string>* args);

	IplImage *getImage(void);
	Mat getDescriptors(void);
	vector<KeyPoint> getKeypoints(void);
	double getScale(void);

	void process( string* trainFile, string* queryFile ); //TODO: Rename
};
