#include "XMLReader.h"

XMLReader::XMLReader(void)
{
	try
	{
		XMLPlatformUtils::Initialize();  
	}
	catch( XMLException& e )
	{
		char* message = XMLString::transcode( e.getMessage() );

		XMLString::release( &message );

	}
}

XMLReader::~XMLReader(void)
{
}

list<Feature*> XMLReader::read(std::string *filename)
{
	list<Feature*> result;

	XercesDOMParser *m_ConfigFileParser = new XercesDOMParser;

	m_ConfigFileParser->setValidationScheme( XercesDOMParser::Val_Never );
	m_ConfigFileParser->setDoNamespaces( false );
	m_ConfigFileParser->setDoSchema( false );
	m_ConfigFileParser->setLoadExternalDTD( false );

	try
	{
		m_ConfigFileParser->parse( filename->c_str() );

		xercesc::DOMDocument* xmlDoc = m_ConfigFileParser->getDocument();

		DOMElement* elementRoot = xmlDoc->getDocumentElement();
		if( !elementRoot ) throw(runtime_error( "empty XML document" ));

		DOMNodeList*      children = elementRoot->getChildNodes();
		const  XMLSize_t nodeCount = children->getLength();

		for( XMLSize_t i = 0; i < nodeCount; ++i )
		{
			DOMNode* currentNode = children->item(i);

			if( currentNode->getNodeType() &&  // true is not NULL
				currentNode->getNodeType() == DOMNode::ELEMENT_NODE ) // is element
			{
				DOMElement* currentElement = dynamic_cast< xercesc::DOMElement* >( currentNode );	
				Feature* task = TaskFactory::createTask(currentElement);
				result.push_back(task);
			}
		}

	}
	catch( XMLException& e )
	{
		char* message = XMLString::transcode( e.getMessage() );
		//ostringstream errBuf;
		//errBuf << "Error parsing file: " << message << flush;
		XMLString::release( &message );
	}
	return result;
}

void XMLReader::close()
{
}