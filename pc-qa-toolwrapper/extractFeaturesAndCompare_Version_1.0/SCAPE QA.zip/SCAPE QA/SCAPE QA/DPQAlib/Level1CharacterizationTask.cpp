#include "Level1CharacterizationTask.h"

Level1CharacterizationTask::Level1CharacterizationTask(DOMElement* elem):CharacterizationTask(elem)
{
	level = 1;
}

Level1CharacterizationTask::Level1CharacterizationTask(void):CharacterizationTask()
{
	level = 1;
}

Level1CharacterizationTask::~Level1CharacterizationTask(void)
{
}