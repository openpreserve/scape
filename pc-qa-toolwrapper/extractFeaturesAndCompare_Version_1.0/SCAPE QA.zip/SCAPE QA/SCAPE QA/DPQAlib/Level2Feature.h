#pragma once

#include "stdafx.h"

#include "Feature.h"

#include <xercesc/dom/DOMElement.hpp>

using namespace xercesc;

class Level2Feature :
	public Feature
{
protected:
	using Feature::level;

public:
	Level2Feature(DOMElement* elem);
	Level2Feature(void);
	~Level2Feature(void);
};
