#pragma once

#include "stdafx.h"

#include "Feature.h"

#include <tclap/CmdLine.h>
#include <list>

using namespace std;

class Characterization
{

private:
	list<Feature*> tasks;

	bool canExecute(Feature* task);

public:
	Characterization(void);
	~Characterization(void);

	void addTask(Feature* task);
	void execute(IplImage* img);
	void writeOutput(void);
	void addCommandLineArgs(TCLAP::CmdLine* cmd);
	void parseCommandLineArgs();

};
