#include "PixelwiseComparison.h"

const string PixelwiseComparison::TASK_NAME = "PixelwiseComparison";

PixelwiseComparison::PixelwiseComparison(void)
{
	name = TASK_NAME;
}

PixelwiseComparison::~PixelwiseComparison(void)
{
}

double PixelwiseComparison::compare(Feature *task)
{
	CvSize sz = cvGetSize( image );

	IplImage *otherImg = ((PixelwiseComparison*)task)->getImage();
	IplImage *diffImage = cvCreateImage( sz, image->depth, 3 );

	cvAbsDiff( image, otherImg, diffImage );

	Mat mx(diffImage);
	
	Scalar s = mean(mx);

	DoubleOutputParameter *param1 = new DoubleOutputParameter("result");
	param1->setData(s.val[0] + s.val[1] + s.val[2]);
	addOutputParameter(*param1);


	return s.val[0] + s.val[1] + s.val[2];
}

void PixelwiseComparison::execute(IplImage *img)
{
	image = img;
}

list<string>* PixelwiseComparison::getCmdlineArguments()
{
	return NULL;
}

void PixelwiseComparison::setCmdlineArguments(list<string> *args)
{
}

void PixelwiseComparison::parseCommandlineArguments()
{
}

IplImage *PixelwiseComparison::getImage(void)
{
	return image;
}