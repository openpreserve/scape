
#include "XercesTest.h"

#include <xercesc/util/PlatformUtils.hpp>

#include <xercesc/dom/DOM.hpp>

#include <xercesc/framework/StdOutFormatTarget.hpp>
#include <xercesc/framework/LocalFileFormatTarget.hpp>
#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/util/XMLUni.hpp>

#include <xercesc/util/OutOfMemoryException.hpp>

XercesTest::XercesTest(void)
{
}

XercesTest::~XercesTest(void)
{
}

void XercesTest::helloWorld(void) {

	// Initilize Xerces.
	XMLPlatformUtils::Initialize();

		XMLCh tempStr1[100];

        XMLString::transcode("Range", tempStr1, 99);
        DOMImplementation* impl = DOMImplementationRegistry::getDOMImplementation(tempStr1);

        XMLString::transcode("root", tempStr1, 99);
        DOMDocument*   doc = impl->createDocument(0, tempStr1, 0);
        DOMElement*   root = doc->getDocumentElement();

        XMLString::transcode("FirstElement", tempStr1, 99);
        DOMElement*   e1 = doc->createElement(tempStr1);
        root->appendChild(e1);

        XMLString::transcode("SecondElement", tempStr1, 99);
        DOMElement*   e2 = doc->createElement(tempStr1);
        root->appendChild(e2);

        XMLString::transcode("aTextNode", tempStr1, 99);
        DOMText*       textNode = doc->createTextNode(tempStr1);
        e1->appendChild(textNode);

        // optionally, call release() to release the resource associated with the range after done
        DOMRange* range = doc->createRange();
        range->release();



        // no need to release this returned object which is owned by implementation
        XMLString::transcode("*", tempStr1, 99);
        DOMNodeList*    nodeList = doc->getElementsByTagName(tempStr1);

        // done with the document, must call release() to release the entire document resources
        

	/*
	The output of the code above will produce the following:

	<?xml version="1.0" encoding="UTF-8" standalone="no" ?>
	<Hello_World/>

	*/

	//
	// If the parse was successful, output the document data from the DOM tree


		// get a serializer, an instance of DOMLSSerializer
		XMLCh tempStr[3] = {chLatin_L, chLatin_S, chNull};
		DOMImplementation *impl2          = DOMImplementationRegistry::getDOMImplementation(tempStr);
		DOMLSSerializer   *theSerializer = ((DOMImplementationLS*)impl2)->createLSSerializer();
		DOMLSOutput       *theOutputDesc = ((DOMImplementationLS*)impl2)->createLSOutput();

		

		
		DOMConfiguration* serializerConfig=theSerializer->getDomConfig();

	
		//
		// Plug in a format target to receive the resultant
		// XML stream from the serializer.
		//
		// StdOutFormatTarget prints the resultant XML stream
		// to stdout once it receives any thing from the serializer.
		//
		
		XMLFormatTarget *myFormTarget = new StdOutFormatTarget();
		theOutputDesc->setByteStream(myFormTarget);


			theSerializer->write(doc, theOutputDesc);

		theOutputDesc->release();
		theSerializer->release();




		// Cleanup.
		doc->release();
		XMLPlatformUtils::Terminate();



	}