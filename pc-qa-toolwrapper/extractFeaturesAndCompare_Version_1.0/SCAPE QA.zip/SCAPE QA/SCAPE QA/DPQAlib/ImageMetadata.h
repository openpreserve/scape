#pragma once

#include "stdafx.h"

#include "XMLUtils.h"

#include "Level1Feature.h"
#include "IntOutputParameter.h"
#include "DoubleOutputParameter.h"
#include "StringConverter.h"

#include <xercesc/dom/DOM.hpp>
#include <xercesc/dom/DOMElement.hpp>

#include <tclap/CmdLine.h>

using namespace xercesc;

class ImageMetadata :
	public Level1Feature
{

private:
	// properties
	int imageWidth;
	int imageHeight;
	int imageChannels;

	void loadData(DOMElement* elem);

protected:
	using Feature::name;

public:
	// constants
	static const string TASK_NAME;
	static const string IMAGE_WIDTH;
	static const string IMAGE_HEIGHT;
	static const string IMAGE_CHANNELS;

	// constructors
	ImageMetadata(DOMElement* elem);
	ImageMetadata(void);
	~ImageMetadata(void);

	// members
	// implement virtual methods
	void   execute(IplImage* image);
	double compare(Feature *task);
	void parseCommandlineArguments();
	list<string>* getCmdlineArguments(void);
	void setCmdlineArguments(list<string>* args);
};

