#include "CharacterizationTask.h"

const string CharacterizationTask::ATTR_LEVEL   = "level";
const string CharacterizationTask::ATTR_NAME    = "name";
const string CharacterizationTask::TAG_NAME     = "task";



CharacterizationTask::CharacterizationTask(DOMElement* elem)
{
}

CharacterizationTask::CharacterizationTask(void)
{
}

CharacterizationTask::~CharacterizationTask(void)
{
	list<OutputParameter>::iterator i;

	
	for(i=outputParams.begin(); i != outputParams.end(); ++i)
	{
		OutputParameter param = *i;
	}

}

void CharacterizationTask::addOutputParameter(OutputParameter param)
{
	outputParams.push_back(param);
}

list<OutputParameter> *CharacterizationTask::getOutputParameters()
{
	return &outputParams;
}

void CharacterizationTask::testOutput(void)
{

	list<OutputParameter>::iterator i;

	
	for(i=outputParams.begin(); i != outputParams.end(); ++i)
	{
		OutputParameter param = *i;
		
		std::string name = *param.getName();
		std::string data = *param.getData();

		
		printf("  <%s",name.c_str());

		if (param.getOutputAttributes().size() > 0)
		{
			list<OutputAttribute> attrs = param.getOutputAttributes();
			list<OutputAttribute>::iterator j;

			for(j=attrs.begin(); j != attrs.end(); ++j)
			{
				OutputAttribute attr = *j;
				printf(" %s=\"%s\"",attr.getName()->c_str(),attr.getValue()->c_str());
			}
		}
		
		printf(">%s</%s>\n",data.c_str(),name.c_str());
	}
}

string CharacterizationTask::getName(void)
{
	return name;
}

int CharacterizationTask::getLevel(void)
{
	return level;
}

void CharacterizationTask::addCharacterizationCommandlineArgument(TCLAP::Arg* arg)
{
	characterizationArguments.push_back(arg);
}

void CharacterizationTask::addComparisonCommandlineArgument(TCLAP::Arg* arg)
{
	comparisonArguments.push_back(arg);
}

list<TCLAP::Arg*>* CharacterizationTask::getCharacterizationCommandlineArguments(void)
{
	return &characterizationArguments;
}

list<TCLAP::Arg*>* CharacterizationTask::getComparisonCommandlineArguments(void)
{
	return &comparisonArguments;
}
