#include "Level1Feature.h"

Level1Feature::Level1Feature(DOMElement* elem):Feature(elem)
{
	level = 1;
}

Level1Feature::Level1Feature(void):Feature()
{
	level = 1;
}

Level1Feature::~Level1Feature(void)
{
}