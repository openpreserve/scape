#pragma once

#include "stdafx.h"

#include <string>

#include <xercesc/dom/DOM.hpp>
#include <xercesc/dom/DOMElement.hpp>

using namespace std;
using namespace xercesc;

class XMLUtils
{
public:
	XMLUtils(void);
	~XMLUtils(void);

	static string getElementValue(DOMElement* elem, const string* name);
	static string getElementValue(DOMElement *rootelem);
	static string xmlChToString(const XMLCh* toTranscode);

};
