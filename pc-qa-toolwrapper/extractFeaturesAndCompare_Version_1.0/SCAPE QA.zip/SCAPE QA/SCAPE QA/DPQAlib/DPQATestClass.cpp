
#include "DPQATestClass.h"

DPQATestClass::DPQATestClass(void)
{
}

DPQATestClass::~DPQATestClass(void)
{
}

void DPQATestClass::helloWorld(void)
{
	printf("Hello World from the lib...!\n");
}